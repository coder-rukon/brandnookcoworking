
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="appoitnment_page thankyou_page">
                <div class="appoinment_page_container">
                        <h2 class="title">We are EXCITED TO MEET YOU!</h2>
                        <h1 class="title">Thank You For <br/>Your Interest</h1>
                        <p>We recieved your interest in visiting Brandnook. Our team will be in touch to schedule a visit as soon as possible.</p>
                        <img src="/images/logo2.png" alt="Brandnook" />
                </div>
        </div>
 <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localserver\htdocs\brandnookcoworking\brandnookcoworking\resources\views/Thankyou.blade.php ENDPATH**/ ?>