

<?php $__env->startSection('content'); ?>
<div class="container">

   <h1 class="appointment_list">Appointment List</h1>
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Company</th>
                <th>Website</th>
                <th>address 1</th>
                <th>address 2</th>
                <th>City</th>
                <th>State</th>
                <th>Zip Code</th>
                <th>Interested in</th>
                <th>Seats Needed</th>
                <th>Desired Start Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $Appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
           
            <tr>
                <td><?php echo e($Appointment->first_name); ?> <?php echo e($Appointment->last_name); ?></td>
                <td><?php echo e($Appointment->email); ?></td>
                <td><?php echo e($Appointment->phone); ?></td>
                <td><?php echo e($Appointment->company); ?></td>
                <td><?php echo e($Appointment->company_website); ?></td>
                <td><?php echo e($Appointment->company_address_line_1); ?></td>
                <td><?php echo e($Appointment->company_address_line_2); ?></td>
                <td><?php echo e($Appointment->city); ?></td>
                <td><?php echo e($Appointment->state); ?></td>
                <td><?php echo e($Appointment->zip_code); ?></td>
                <td><?php echo e($Appointment->interested_in); ?></td>
                <td><?php echo e($Appointment->seats_needed); ?></td>
                <td><?php echo e($Appointment->desired_start_date); ?></td>
            </tr>
            
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\localserver\htdocs\brandnookcoworking\brandnookcoworking\resources\views/home.blade.php ENDPATH**/ ?>